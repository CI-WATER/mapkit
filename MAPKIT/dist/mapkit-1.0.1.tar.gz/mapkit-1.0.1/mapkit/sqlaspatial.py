'''
********************************************************************************
* Name: sqlaspatial
* Author: Nathan Swain
* Created On: January 3, 2014
* Copyright: (c) Brigham Young University 2014
* License: BSD 2-Clause
********************************************************************************
'''


# from mapkit.sqlatypes import Raster
#  
# class ST_AsGDALRaster(GenericFunction):
#     '''
#     '''
#     name = 'ST_AsGDALRaster'
